var content = {
  "code": 200,
  "mesagge": "DELETE SUCCESS"
}

context.setVariable("response.content",JSON.stringify(content));